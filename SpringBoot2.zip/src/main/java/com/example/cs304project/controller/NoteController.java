package com.example.cs304project.controller;

public class NoteController {

    //post /api/notes 创建笔记

    //put /api/notes/{noteId} 更新笔记信息

    //get /api/notes/{noteId} 获取笔记详情

    //get /api/lectures/{lectureId}/notes 获取某课程所有笔记

    //delete /api/notes/{noteId} 删除笔记
}
