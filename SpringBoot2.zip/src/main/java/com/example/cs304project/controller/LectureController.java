package com.example.cs304project.controller;

public class LectureController {

    //post /api/lectures 创建新讲座

    //put /api/lectures/{lecturesId} 更新讲座信息

    //get /api/lectures/{lecturesId} 根据id获取讲座信息

    //get /api/lectures/{lectureOrder} 根据讲座顺序设置讲座信息

    //get /api/courses/{courseId}/lectures 获取某课程所有讲座

    //delete /api/lectures/{lectureId} 删除讲座
}
