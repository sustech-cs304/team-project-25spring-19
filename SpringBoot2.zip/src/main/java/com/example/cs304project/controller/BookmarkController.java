package com.example.cs304project.controller;

public class BookmarkController {

    //post /api/bookmarks

    //put /api/bookmarks/{bookmarkId}

    //get /api/bookmarks/{bookmarkId}

    //get /api/Users/{userId}/bookmarks

    //delete /api/bookmark/{bookmarks}
}
