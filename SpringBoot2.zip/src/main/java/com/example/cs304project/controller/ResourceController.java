package com.example.cs304project.controller;

public class ResourceController {
}
