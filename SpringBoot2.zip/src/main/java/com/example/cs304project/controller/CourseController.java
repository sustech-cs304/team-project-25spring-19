package com.example.cs304project.controller;


import com.example.cs304project.dto.CourseDTO;
import com.example.cs304project.entity.Course;
import com.example.cs304project.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;

    //post /api/courses/create 创建课程
    @PostMapping("/create")
    public ResponseEntity<CourseDTO> createCourse(@RequestBody CourseDTO courseDTO){
        Course course = new Course();
        course.setTitle(courseDTO.getTitle());
        course.setDescription(courseDTO.getDescription());
        course.setLectureNum(courseDTO.getLectureNum());

        Course created = courseService.createCourse(courseDTO.getInstructorId(),course);

        CourseDTO resultDTO = new CourseDTO();
        resultDTO.setCourseId(created.getCourseId());
        resultDTO.setDescription(created.getDescription());
        resultDTO.setTitle(created.getTitle());
        resultDTO.setLectureNum(created.getLectureNum());
        resultDTO.setInstructorId(created.getInstructor().getUserId());

        return ResponseEntity.ok(resultDTO);

    }

    //post /api/courses/add
    @PostMapping("/add")
    public ResponseEntity<CourseDTO> addCourse(@RequestParam Long userId,
                                               @RequestParam Long courseId){


        Course created = courseService.addCourse(userId,courseId);

        CourseDTO resultDTO = new CourseDTO();
        resultDTO.setCourseId(created.getCourseId());
        resultDTO.setDescription(created.getDescription());
        resultDTO.setTitle(created.getTitle());
        resultDTO.setLectureNum(created.getLectureNum());
        resultDTO.setInstructorId(created.getInstructor().getUserId());

        return ResponseEntity.ok(resultDTO);

    }
    //put /api/courses/{courseId} 更新课程信息
    @PutMapping("{courseId}")
    public ResponseEntity<CourseDTO> updateCourse(@PathVariable Long courseId,
                                                  @RequestParam Long userId,
                                                  @RequestBody CourseDTO courseDTO){

        Course course = new Course();
        course.setCourseId(courseId);
        course.setTitle(courseDTO.getTitle());
        course.setDescription(courseDTO.getDescription());
        course.setLectureNum(courseDTO.getLectureNum());

        Course updated = courseService.updateCourse(userId,course);

        CourseDTO resultDTO = new CourseDTO();
        resultDTO.setCourseId(updated.getCourseId());
        resultDTO.setDescription(updated.getDescription());
        resultDTO.setTitle(updated.getTitle());
        resultDTO.setLectureNum(updated.getLectureNum());
        resultDTO.setInstructorId(updated.getInstructor().getUserId());

        return ResponseEntity.ok(resultDTO);
    }

    //get /api/courses/{courseId} 根据id获取课程
    @GetMapping("{courseId}")
    public ResponseEntity<CourseDTO> getCourseById(@PathVariable("courseId") Long courseId){

        Course course = courseService.getCourseById(courseId);
        CourseDTO courseDTO = new CourseDTO();
        courseDTO.setCourseId(course.getCourseId());
        courseDTO.setTitle(course.getTitle());
        courseDTO.setInstructorId(course.getInstructor().getUserId());
        courseDTO.setDescription(course.getDescription());
        courseDTO.setLectureNum(course.getLectureNum());
        return ResponseEntity.ok(courseDTO);
    }

    //get /api/courses/tittle 根据课程名获取课程
    @GetMapping("/tittle")
    public ResponseEntity<List<CourseDTO>> getCourseByTittle(@RequestParam String tittle){

        List<Course> courses = courseService.getCourseByTittle(tittle);
        List<CourseDTO> courseDTOS = courses.stream().map(course -> {
            CourseDTO dto = new CourseDTO();
            dto.setCourseId(course.getCourseId());
            dto.setTitle(course.getTitle());
            dto.setInstructorId(course.getInstructor().getUserId());
            dto.setDescription(course.getDescription());
            dto.setLectureNum(course.getLectureNum());
            return dto;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(courseDTOS);
    }
    //get /api/courses/user 获取某个学生或教师的所有课程
    @GetMapping("/user")
    public ResponseEntity<List<CourseDTO>> getCourseByUser(@RequestParam Long userId){


        List<Course> courses = courseService.listAllCourse(userId);
        List<CourseDTO> courseDTOS = courses.stream().map(course -> {
            CourseDTO dto = new CourseDTO();
            dto.setCourseId(course.getCourseId());
            dto.setTitle(course.getTitle());
            dto.setInstructorId(course.getInstructor().getUserId());
            dto.setDescription(course.getDescription());
            dto.setLectureNum(course.getLectureNum());
            return dto;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(courseDTOS);
    }

    //delete /api/courses/{courseId} 删除课程
    @DeleteMapping("{courseId}")
    public ResponseEntity<String> deleteCourse(@PathVariable Long courseId){
        courseService.deleteCourse(courseId);
        return ResponseEntity.ok("课程成功删除");
    }

}
