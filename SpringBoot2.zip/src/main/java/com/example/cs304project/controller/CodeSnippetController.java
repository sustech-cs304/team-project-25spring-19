package com.example.cs304project.controller;


import com.example.cs304project.dto.CodeSnippetDTO;
import com.example.cs304project.entity.CodeSnippet;
import com.example.cs304project.service.CodeSnippetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/codes")
public class CodeSnippetController {


    @Autowired
    private CodeSnippetService codeSnippetService;

}
