package com.example.cs304project.service;

public class ExerciseService {

    //创建练习题或作业，仅限教师
    public void createExercise(){}

    //更新练习题或作业内容，仅限教师
    public void updateExercise(){}

    //获取某课程全部练习题
    public void getExerciseByCourse(){}

    //获取某讲座全部练习题
    public void getExerciseByLecture(){}

    //获取某习题的答案
    public void getAnswerById(){}

    //删除练习题
    public void deleteExercise(){}
}
