package com.example.cs304project.service;


import com.example.cs304project.entity.CodeSnippet;
import com.example.cs304project.entity.LectureSlide;
import com.example.cs304project.exception.ResourceNotFoundException;
import com.example.cs304project.repository.CodeSnippetRepository;
import com.example.cs304project.repository.LectureSlideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CodeSnippetService {


    @Autowired
    private CodeSnippetRepository codeSnippetRepository;

    @Autowired
    private LectureSlideRepository lectureSlideRepository;


}
