package com.example.cs304project.service;

public class SubmissionService {

    //创建答案或代码
    public void createSubmission(){}

    //更新答案或代码
    public void updateSubmission(){}

    //获取某个题的所有答案
    public void getSubmissionByExercise(){}

    //获取某个学生的所有答案
    public void getSubmissionByUser(){}

    //获取某个学生的所有评分
    public void getScoreByUser(){}

    //删除答案或代码
    public void deleteSubmission(){}

    //
}
