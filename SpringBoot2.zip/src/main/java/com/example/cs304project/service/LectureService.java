package com.example.cs304project.service;

public class LectureService {

    //创建讲座,仅限教师
    public void createLecture(){}

    //更新讲座信息
    public void updateLecture(){}

    //根据id获取讲座信息
    public void getLectureById(){}

    //根据order获取讲座信息
    public void getLectureByOrder(){}

    //获取某课程中全部讲座信息
    public void getAllLecture(){}

    //删除指定讲座
    public void deleteLecture(){}

    //
}
