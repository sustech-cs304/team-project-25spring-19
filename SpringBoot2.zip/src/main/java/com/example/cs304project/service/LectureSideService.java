package com.example.cs304project.service;

public class LectureSideService {

    //创建新课件
    public void createSlide(){}
    //更改课件内容或顺序
    public void updateSlide(){}

    //根据id获取课件内容
    public void getSlideByIs(){}

    //根据课件顺序获取课件内容
    public void getSlideByOrder(){}

    //获取讲座的所有课件
    public void getAllSlides(){}

    //删除课件
    public void deleteSlide(){}
}
