package com.example.cs304project.service;

public class DiscussionService {

    //发布讨论
    public void createDiscussion(){}
    //获取帖子的详情信息
    public void getDiscussionById(){}

    //获取某节课的全部讨论内容
    public void getDiscussionByLecture(){}

    //获取某用户的全部发言
    public void getDiscussionByUser(){}

    //删除发言或回复
    public void deleteDiscussion(){}

}
