package com.example.cs304project.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "Lectures")
public class Lecture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lectureId;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    public Long getLectureId() {
        return lectureId;
    }

    public void setLectureId(Long lectureId) {
        this.lectureId = lectureId;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getLectureOrder() {
        return lectureOrder;
    }

    public void setLectureOrder(Integer lectureOrder) {
        this.lectureOrder = lectureOrder;
    }

    public String getSlideNum() {
        return slideNum;
    }

    public void setSlideNum(String slideNum) {
        this.slideNum = slideNum;
    }

    private String tittle;

    @Column(columnDefinition = "TEXT")
    private String description;

    private Integer lectureOrder;

    public Lecture(Long lectureId, Course course, String tittle, String description, Integer lectureOrder, String slideNum) {
        this.lectureId = lectureId;
        this.course = course;
        this.tittle = tittle;
        this.description = description;
        this.lectureOrder = lectureOrder;
        this.slideNum = slideNum;
    }

    @Column(length = 20)
    private String slideNum;

    public Lecture() {

    }
}
