package com.example.cs304project.repository;


import com.example.cs304project.entity.ResourceSharing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResourceSharingRepository extends JpaRepository<ResourceSharing,Long> {
}
