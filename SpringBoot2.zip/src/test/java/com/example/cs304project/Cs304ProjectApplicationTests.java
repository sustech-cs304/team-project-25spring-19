package com.example.cs304project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cs304ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
