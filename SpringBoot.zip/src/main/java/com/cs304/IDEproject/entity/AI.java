package com.cs304.IDEproject.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "AI_Assistant")
public class AI {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long AIId;

    @ManyToOne
    @JoinColumn(name = "lecture_id")
    private Lecture lecture;

    @ManyToOne
    @JoinColumn(name = "slide_id")
    private LectureSlide slide;

    @ManyToOne
    @JoinColumn(name = "submission_id")
    private Submission submission;

    @Column(columnDefinition = "TEXT")
    private String summary;

    @Column(columnDefinition = "TEXT")
    private String mindMap;

    @Column(columnDefinition = "TEXT")
    private String quiz;

}
