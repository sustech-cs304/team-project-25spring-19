package com.cs304.IDEproject.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Lectures")
public class Lecture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long LectureId;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private String tittle;

    @Column(columnDefinition = "TEXT")
    private String description;

    private Integer LectureOrder;

    @Column(length = 20)
    private String SlideNum;

}
