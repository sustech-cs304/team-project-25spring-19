package com.cs304.IDEproject.exception;

public class CodeExecutionException extends RuntimeException{
    public CodeExecutionException(String message){
        super(message);
    }
}
