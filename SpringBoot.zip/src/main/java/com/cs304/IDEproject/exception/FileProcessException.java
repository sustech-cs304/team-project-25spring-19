package com.cs304.IDEproject.exception;

public class FileProcessException extends RuntimeException{
    public FileProcessException(String message){
        super(message);
    }
}
