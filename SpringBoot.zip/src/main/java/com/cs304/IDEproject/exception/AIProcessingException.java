package com.cs304.IDEproject.exception;

public class AIProcessingException extends RuntimeException{
    public AIProcessingException(String message){
        super(message);
    }
}
