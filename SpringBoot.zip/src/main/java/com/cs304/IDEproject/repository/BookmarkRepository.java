package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.Bookmark;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookmarkRepository extends JpaRepository<Bookmark,Long> {
}
