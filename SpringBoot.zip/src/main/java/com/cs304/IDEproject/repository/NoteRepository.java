package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.Note;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NoteRepository extends JpaRepository<Note,Long> {
}
