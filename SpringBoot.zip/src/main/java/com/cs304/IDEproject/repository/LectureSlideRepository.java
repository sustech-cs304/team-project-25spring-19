package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.LectureSlide;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LectureSlideRepository extends JpaRepository<LectureSlide,Long> {
}
