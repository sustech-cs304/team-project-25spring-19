package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.Exercise;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExerciseRepository extends JpaRepository<Exercise,Long> {
}
