package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.Discussion;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DiscussionRepository extends JpaRepository<Discussion,Long> {
}
