package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.ResourceSharing;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResourceSharingRepository extends JpaRepository<ResourceSharing,Long> {
}
