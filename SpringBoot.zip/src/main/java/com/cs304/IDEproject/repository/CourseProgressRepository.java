package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.CourseProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseProgressRepository extends JpaRepository<CourseProgress,Long> {
}
