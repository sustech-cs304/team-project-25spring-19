package com.cs304.IDEproject.repository;

import com.cs304.IDEproject.entity.Submission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubmissionRepository extends JpaRepository<Submission,Long> {
}
