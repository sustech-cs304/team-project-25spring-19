package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Course;
import com.cs304.IDEproject.entity.Lecture;
import com.cs304.IDEproject.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResourceDTO {
    private Long ResourceId;

    private Long courseId;

    private Long lectureId;

    private Long userId;

    private String type;

    private String link;

    private String description;

}
