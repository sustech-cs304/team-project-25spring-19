package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Course;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LectureDTO {

    private Long LectureId;

    private Long courseId;

    private String tittle;

    private String description;

    private Integer LectureOrder;

    private String SlideNum;
}
