package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseDTO {

    private Long courseId;

    private String title;

    private String description;

    private Long instructorId;

    private String lectureNum;

}
