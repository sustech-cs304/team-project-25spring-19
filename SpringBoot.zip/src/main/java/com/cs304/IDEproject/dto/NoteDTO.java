package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Lecture;
import com.cs304.IDEproject.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoteDTO {

    private Long NoteId;

    private Long userId;

    private Long lectureId;

    private String content;
}
