package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Course;
import com.cs304.IDEproject.entity.Discussion;
import com.cs304.IDEproject.entity.Lecture;
import com.cs304.IDEproject.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DiscussionDTO {

    private Long DiscussionId;

    private Long courseId;

    private Long userId;

    private Long lectureId;

    private String context;

    private Long parentId;
}
