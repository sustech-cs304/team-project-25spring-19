package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Lecture;
import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LectureSlideDTO {

    private Long SlideId;

    private Long lectureId;

    private Integer order;

    private String content;

    private String url;

    private String extractedTEXT;

}
