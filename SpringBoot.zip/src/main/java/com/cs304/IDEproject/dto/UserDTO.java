package com.cs304.IDEproject.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    private Long Id;
    
    private String username;

    private String email;

    private String role;

    private String password;


    public UserDTO(Long id, String username, String email, String role) {
        return;
    }
}
