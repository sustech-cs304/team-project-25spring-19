package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Course;
import com.cs304.IDEproject.entity.Lecture;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExerciseDTO {

    private Long ExerciseId;

    private Long courseId;

    private Long lectureId;

    private String question;

    private String answer;


}
