package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Lecture;
import com.cs304.IDEproject.entity.LectureSlide;
import com.cs304.IDEproject.entity.Submission;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AIDTO {

    private Long AIId;

    private Long lectureId;

    private Long slideId;

    private Long submissionId;

    private String summary;

    private String mindMap;

    private String quiz;
}
