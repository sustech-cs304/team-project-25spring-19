package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Lecture;
import com.cs304.IDEproject.entity.LectureSlide;
import com.cs304.IDEproject.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class BookmarkDTO {

    private Long BookmarkId;

    private Long userId;

    private Long lectureId;

    private Long slideId;

    private Integer pageNum;

    private String data;


}
