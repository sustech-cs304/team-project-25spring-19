package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.Exercise;
import com.cs304.IDEproject.entity.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubmissionDTO {
    private Long SubmissionId;

    private Long exerciseId;

    private Long studentId;

    private String content;

    private BigDecimal score;

}
