package com.cs304.IDEproject.dto;

import com.cs304.IDEproject.entity.LectureSlide;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CodeSnippetDTO {

    private Long CodeSnippetId;

    private Long slideId;

    private String context;

    private String result;

    private String language;

    private boolean executeNow; // 是否立即执行 (前端可用此标志)
}
