package com.cs304.IDEproject.service;

import com.cs304.IDEproject.entity.CodeSnippet;
import com.cs304.IDEproject.entity.LectureSlide;
import com.cs304.IDEproject.exception.ResourceNotFoundException;
import com.cs304.IDEproject.repository.CodeSnippetRepository;
import com.cs304.IDEproject.repository.LectureSlideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CodeSnippetService {


    @Autowired
    private CodeSnippetRepository codeSnippetRepository;

    @Autowired
    private LectureSlideRepository lectureSlideRepository;

    /**
     * 创建代码片段，若需要立即执行则可在这里调用 execute 方法
     * @param slideId 幻灯片ID (可选, 也可为null)
     * @param context 代码文本
     * @param language 代码语言
     * @param executeNow 是否立即执行
     * @return 创建后的 CodeSnippet 对象
     */
    public CodeSnippet createSnippet(Long slideId, String context, String language, boolean executeNow) {
        // 如果 slideId 不为空，则获取对应的 LectureSlide
        LectureSlide slide = null;
        if (slideId != null) {
            slide = lectureSlideRepository.findById(slideId)
                    .orElseThrow(() -> new ResourceNotFoundException("Slide with id " + slideId + " not found"));
        }

        // 构造实体
        CodeSnippet snippet = new CodeSnippet();
        snippet.setSlide(slide);
        snippet.setContext(context);
        snippet.setLanguage(language);
        snippet.setResult(null);  // 初始没有执行结果

        // 先保存数据库
        snippet = codeSnippetRepository.save(snippet);

        // 如果需要立即执行
        if (executeNow) {
            snippet = executeCode(snippet.getCodeSnippetId());
        }
        return snippet;
    }

    /**
     * 执行代码：在本地编译/解释器里运行，并将结果更新到 snippet.result
     * @param snippetId 代码片段ID
     * @return 更新后的 CodeSnippet (包含执行结果)
     */
    public CodeSnippet executeCode(Long snippetId) {
        CodeSnippet snippet = codeSnippetRepository.findById(snippetId)
                .orElseThrow(() -> new ResourceNotFoundException("CodeSnippet with id " + snippetId + " not found"));

        // 1. 获取代码内容 + 语言
        String code = snippet.getContext();
        String lang = snippet.getLanguage();

        // 2. 调用本地执行
        String executionResult;
        try {
            executionResult = runLocalProcess(code, lang);
        } catch (Exception e) {
            throw new RuntimeException("Code execution failed: " + e.getMessage(), e);
        }

        // 3. 保存并返回
        snippet.setResult(executionResult);
        return codeSnippetRepository.save(snippet);
    }

    /**
     * 用 ProcessBuilder 执行系统命令
     */
    private String runLocalProcess(String code, String language) throws Exception {
        // 真实情况需创建临时文件, 调用 python/java 等编译运行命令
        ProcessBuilder pb;
        if ("python".equalsIgnoreCase(language)) {
            pb = new ProcessBuilder("echo", code);
        } else if ("java".equalsIgnoreCase(language)) {
            pb = new ProcessBuilder("echo", "Java code => " + code);
        } else {
            pb = new ProcessBuilder("echo", "Unsupported language => " + language);
        }

        Process process = pb.start();
        // 读取标准输出
        String output = new BufferedReader(new InputStreamReader(process.getInputStream()))
                .lines()
                .collect(Collectors.joining("\n"));

        int exitCode = process.waitFor();
        if (exitCode != 0) {
            // 读取错误输出
            String error = new BufferedReader(new InputStreamReader(process.getErrorStream()))
                    .lines()
                    .collect(Collectors.joining("\n"));
            throw new Exception("Process exited with " + exitCode + ": " + error);
        }

        return output;
    }

    /**
     * 根据ID获取代码片段
     */
    public CodeSnippet getSnippetById(Long snippetId) {
        return codeSnippetRepository.findById(snippetId)
                .orElseThrow(() -> new ResourceNotFoundException("CodeSnippet with id " + snippetId + " not found"));
    }

    /**
     * 获取某个幻灯片下的所有代码片段
     */
    public List<CodeSnippet> getSnippetsBySlide(Long slideId) {
        return codeSnippetRepository.findBySlide_SlideId(slideId);
    }

    /**
     * 删除代码片段
     */
    public void deleteSnippet(Long snippetId) {
        CodeSnippet snippet = getSnippetById(snippetId);
        codeSnippetRepository.delete(snippet);
    }

    /**
     * 更新代码片段
     * @param snippetId 代码片段ID
     * @param newContext 新代码
     * @param newLanguage 新语言
     * @return 更新后的 CodeSnippet
     */
    public CodeSnippet updateSnippet(Long snippetId, String newContext, String newLanguage) {
        CodeSnippet snippet = getSnippetById(snippetId);
        snippet.setContext(newContext);
        snippet.setLanguage(newLanguage);
        // 重置 result
        snippet.setResult(null);
        return codeSnippetRepository.save(snippet);
    }

}
