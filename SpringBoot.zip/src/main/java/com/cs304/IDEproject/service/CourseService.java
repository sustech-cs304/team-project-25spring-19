package com.cs304.IDEproject.service;

import com.cs304.IDEproject.entity.Course;
import com.cs304.IDEproject.entity.User;
import com.cs304.IDEproject.exception.ResourceNotFoundException;
import com.cs304.IDEproject.repository.CourseRepository;
import com.cs304.IDEproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService {
/*
    //创建课程，仅限教师
    public void createCourse(){}

    //更新课程信息，仅限教师
    public void updateCourse(){}

    //查询课程,根据Id
    public void getCourseById(){}

    //查询课程，根据tittle
    public void getCourseByTittle(){}

    //查询某学生或教师所有课程
    public void listAllCourse(){}

    //删除课程
    public void deleteCourse(){}*/


    @Autowired  // 自动注入 CourseRepository
    private CourseRepository courseRepository;

    @Autowired  // 自动注入 UserRepository，用于查找讲师
    private UserRepository userRepository;

    /**
     * 创建课程
     * 通过 instructorId 查找讲师（User），若不存在则抛出异常
     * @param title 课程标题
     * @param description 课程描述
     * @param instructorId 讲师的用户ID
     * @param lectureNum 课程节数信息
     * @return 创建的 Course 实体
     */
    public Course createCourse(String title, String description, Long instructorId, String lectureNum) {
        // 查找讲师用户，如果未找到则抛出 ResourceNotFoundException
        User instructor = userRepository.findById(instructorId)
                .orElseThrow(() -> new ResourceNotFoundException("Instructor with id " + instructorId + " not found"));

        Course course = new Course(title, description, instructor, lectureNum);
        return courseRepository.save(course);
    }

    /**
     * 获取所有课程
     * @return 课程列表
     */
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    /**
     * 根据ID获取课程
     * 若课程不存在，则抛出 ResourceNotFoundException
     * @param id 课程ID
     * @return Course 实体
     */
    public Course getCourseById(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course with id " + id + " not found"));
    }
}
