package com.cs304.IDEproject.service;

public class BookmarkService {

    //创建书签
    public void createBookmark(){}

    //更新书签位置
    public void updateBookmark(){}

    //获取书签详情
    public void getBookmarkById(){}

    //获取一个用户的所有书签
    public void getBookmarkByUser(){}

    //删除书签
    public void deleteBookmark(){}

    //
}
