package com.cs304.IDEproject.service;

import com.cs304.IDEproject.entity.User;
import com.cs304.IDEproject.exception.ResourceNotFoundException;
import com.cs304.IDEproject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserService {

/*    //注册新用户，设置初始信息
    public void createUser(){}

    //自定义个人资料，更新用户信息
    public void updateUser(){}

    //修改密码
    public void changePassword(){}

    //根据id查询用户
    public void getUserById(){}

    //根据用户名查询用户
    public void getUserByName(){}

    //列出所有用户
    public void AllUser(){}

    //设置角色：认证教师等
    public void assignRole(){}

    //注销账号
    public void deleteUser(){}*/

    @Autowired
    private UserRepository userRepository;

    /**
     * 创建用户
     * @param user 用户实体对象
     * @return 保存后的用户实体
     */
    public User createUser(User user) {
        return userRepository.save(user);
    }

    /**
     * 查询所有用户
     * @return 用户列表
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * 根据ID查询用户
     * 如果用户不存在，则抛出 ResourceNotFoundException 异常
     * @param userId 用户ID
     * @return 用户实体
     */
    public User getUserById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User with id " + userId + " not found"));
    }
}
