package com.cs304.IDEproject.service;

public class NoteService {

    //创建笔记
    public void createNote(){}

    //更新笔记内容
    public void updateNote(){}

    //根据id获取笔记详情
    public void getNoteById(){}

    //获取某学生在某讲座的笔记
    public void listNote(){}

    //删除笔记
    public void deleteNote(){}

    //
}
