package com.cs304.IDEproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cs304ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cs304ProjectApplication.class, args);
	}

}
