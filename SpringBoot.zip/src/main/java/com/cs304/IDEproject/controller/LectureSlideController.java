package com.cs304.IDEproject.controller;

public class LectureSlideController {

    //post /api/slides 创建课件

    //put /api/slides/{slideId} 更新课件

    //get /api/slides/{slideId} 根据id获取课件链接或课件内容

    //get /api/slides/{slideOrder} 根据课件顺序获取课件

    //get /api/lectures/{lectureId}/slides 获取讲座所有课件

    //delete /api/slides/{slideId} 删除课件
}
