package com.cs304.IDEproject.controller;

public class DiscussionController {

    //post /api/discussions 发布帖子或回复

    //get /api/discussions/{discussionId} 获取帖子详情信息

    //get /api/lectures/{lectureId}/discussions 获取某讲座全部回复

    //get /api/user/{userId}/discussions 获取某用户全部回复

    //delete /api/discussions/{discussionId} 删除回复

    //
}
