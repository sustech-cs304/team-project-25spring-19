package com.cs304.IDEproject.controller;

import com.cs304.IDEproject.dto.CourseDTO;
import com.cs304.IDEproject.entity.Course;
import com.cs304.IDEproject.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/courses")
public class CourseController {

/*    //post /api/courses 创建课程

    //put /api/courses/{courseId} 更新课程信息

    //get /api/courses/{courseId} 根据id获取课程

    //get /api/courses/{courseTittle} 根据课程名获取课程

    //get /api/courses 获取某个学生或教师的所有课程

    //delete /api/courses/{courseId} 删除课程*/

    @Autowired  // 自动注入 CourseService
    private CourseService courseService;

    /**
     * 创建课程
     * 前端提交 CourseDTO 数据，后端调用 Service 层创建课程，
     * 然后将 Course 实体转换为 CourseDTO 返回给前端
     *
     * @param courseDTO 前端传入的课程数据（DTO 对象）
     * @return 创建成功后的课程数据（DTO 对象）
     */
    @PostMapping
    public CourseDTO createCourse(@RequestBody CourseDTO courseDTO) {
        Course created = courseService.createCourse(
                courseDTO.getTitle(),
                courseDTO.getDescription(),
                courseDTO.getInstructorId(),
                courseDTO.getLectureNum()
        );
        return mapToDTO(created);
    }

    /**
     * 获取所有课程
     * @return 课程 DTO 列表
     */
    @GetMapping
    public List<CourseDTO> getAllCourses() {
        return courseService.getAllCourses().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    /**
     * 获取指定课程
     * 若课程不存在，CourseService 中将抛出 ResourceNotFoundException，
     *
     * @param id 课程ID
     * @return 课程 DTO 对象
     */
    @GetMapping("/{id}")
    public CourseDTO getCourseById(@PathVariable("id") Long id) {
        Course course = courseService.getCourseById(id);
        return mapToDTO(course);
    }

    /**
     * 辅助方法：将 Course 实体转换为 CourseDTO 对象
     * @param course 课程实体
     * @return 课程 DTO
     */
    private CourseDTO mapToDTO(Course course) {
        Long instructorId = course.getInstructor() != null ? course.getInstructor().getId() : null;
        return new CourseDTO(
                course.getCourseId(),
                course.getTitle(),
                course.getDescription(),
                instructorId,
                course.getLectureNum()
        );
    }
}
