package com.cs304.IDEproject.controller;

public class SubmissionController {

    //post /api/submissions  提交答案

    //put /api/submissions/{submissionId} 修改答案

    //get /api/exercises/{exerciseId}/submissions 获取某练习的所有答案

    //get /api/users/{userId}/submissions 获取某学生的所有答案

    //get /api/users/{userId}/scores 获取某学生的分数

    //delete /api/submissions/{submissionId} 删除答案

    //
}
