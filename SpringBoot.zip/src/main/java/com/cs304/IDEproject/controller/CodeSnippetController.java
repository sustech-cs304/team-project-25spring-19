package com.cs304.IDEproject.controller;

import com.cs304.IDEproject.dto.CodeSnippetDTO;
import com.cs304.IDEproject.entity.CodeSnippet;
import com.cs304.IDEproject.service.CodeSnippetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/codes")
public class CodeSnippetController {


    @Autowired
    private CodeSnippetService codeSnippetService;

    /**
     * POST /api/snippets
     * 创建代码片段，并可选择是否立即执行
     */
    @PostMapping
    public CodeSnippetDTO createSnippet(@RequestBody CodeSnippetDTO dto) {
        // 这里的 dto 中包含：slideId, context(代码内容), language, executeNow(是否立即执行)
        CodeSnippet snippet = codeSnippetService.createSnippet(
                dto.getSlideId(),
                dto.getContext(),
                dto.getLanguage(),
                dto.isExecuteNow()
        );
        return mapToDTO(snippet);
    }

    /**
     * POST /api/snippets/{snippetId}/execute
     * 仅执行已有代码
     */
    @PostMapping("/{snippetId}/execute")
    public CodeSnippetDTO executeSnippet(@PathVariable Long snippetId) {
        CodeSnippet snippet = codeSnippetService.executeCode(snippetId);
        return mapToDTO(snippet);
    }

    /**
     * GET /api/snippets/{snippetId}
     * 获取代码片段详细信息
     */
    @GetMapping("/{snippetId}")
    public CodeSnippetDTO getSnippetById(@PathVariable Long snippetId) {
        CodeSnippet snippet = codeSnippetService.getSnippetById(snippetId);
        return mapToDTO(snippet);
    }

    /**
     * GET /api/snippets/slide/{slideId}
     * 获取某张幻灯片下的所有代码片段
     */
    @GetMapping("/slide/{slideId}")
    public List<CodeSnippetDTO> getSnippetsBySlide(@PathVariable Long slideId) {
        List<CodeSnippet> snippets = codeSnippetService.getSnippetsBySlide(slideId);
        return snippets.stream().map(this::mapToDTO).collect(Collectors.toList());
    }

    /**
     * DELETE /api/snippets/{snippetId}
     * 删除指定代码片段
     */
    @DeleteMapping("/{snippetId}")
    public void deleteSnippet(@PathVariable Long snippetId) {
        codeSnippetService.deleteSnippet(snippetId);
    }

    /**
     * PUT /api/snippets/{snippetId}
     * 更新代码片段
     */
    @PutMapping("/{snippetId}")
    public CodeSnippetDTO updateSnippet(
            @PathVariable Long snippetId,
            @RequestBody CodeSnippetDTO dto
    ) {
        CodeSnippet snippet = codeSnippetService.updateSnippet(
                snippetId,
                dto.getContext(),
                dto.getLanguage()
        );
        return mapToDTO(snippet);
    }

    // ========== 辅助方法 ==========
    private CodeSnippetDTO mapToDTO(CodeSnippet snippet) {
        CodeSnippetDTO dto = new CodeSnippetDTO();
        dto.setCodeSnippetId(snippet.getCodeSnippetId());

        // 若 slide 不为空，获取 slideId
        if (snippet.getSlide() != null) {
            dto.setSlideId(snippet.getSlide().getSlideId());
        }
        dto.setContext(snippet.getContext());
        dto.setResult(snippet.getResult());
        dto.setLanguage(snippet.getLanguage());
        // 是否立即执行在返回时可以忽略，或看需求
        dto.setExecuteNow(false);
        return dto;
    }
}
