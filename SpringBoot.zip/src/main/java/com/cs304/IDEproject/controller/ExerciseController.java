package com.cs304.IDEproject.controller;

public class ExerciseController {

    //post /api/exercises 创建作业练习

    //put /api/exercises/{exerciseId} 修改练习内容

    //get /api/courses/{courseId}/exercises 获取一门课的所有练习

    //get /api/lectures/{lectureId}/exercises 获取一节讲座的所有练习

    //get /api/exercises/{exerciseId}

    //delete /api/exercises/{exerciseId} 删除练习

    //
}
