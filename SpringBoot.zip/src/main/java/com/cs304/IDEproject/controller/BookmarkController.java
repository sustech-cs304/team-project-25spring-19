package com.cs304.IDEproject.controller;

public class BookmarkController {

    //post /api/bookmarks

    //put /api/bookmarks/{bookmarkId}

    //get /api/bookmarks/{bookmarkId}

    //get /api/Users/{userId}/bookmarks

    //delete /api/bookmark/{bookmarks}
}
