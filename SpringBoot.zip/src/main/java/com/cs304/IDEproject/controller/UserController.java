package com.cs304.IDEproject.controller;

import com.cs304.IDEproject.dto.UserDTO;
import com.cs304.IDEproject.entity.User;
import com.cs304.IDEproject.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController  // 返回 JSON 数据
@RequestMapping("/api/users")  // 定义统一的 URL 前缀
public class UserController {
/*
    //post /api/users/register 注册新用户

    //put /api/users/{userId}/profile 更改用户信息

    //post /api/users/{userId}/password 更改用户密码

    //get /api/users/{userId} 根据id获取用户信息

    //get /api/users/{userName} 根据姓名获取用户信息

    //get /api/users 获取所有用户

    //post /api/users/{userId}/role 设置用户角色

    //delete /api/users/{userId} 注销账号*/


    @Autowired
    private UserService userService;

    /**
     * 创建用户
     * 前端通过 POST 请求提交用户注册信息（UserDTO），后端将其转换为 User 实体保存到数据库中，
     * 然后将保存后的用户信息转换回 UserDTO 返回给前端。
     *
     * @param userDTO 前端传入的用户数据（DTO 对象）
     * @return 保存后的用户数据（DTO 对象），不包含敏感信息如密码
     */
    @PostMapping
    public UserDTO createUser(@RequestBody UserDTO userDTO) {

        String rawPassword = userDTO.getPassword();

        // 对密码进行加密
        String encryptedPassword = new BCryptPasswordEncoder(Integer.parseInt(rawPassword)).toString();

        User user = new User(
                userDTO.getUsername(),
                userDTO.getEmail(),
                encryptedPassword,   // 用加密后的密码代替,
                userDTO.getRole(),
                "默认profile"
        );

        User created = userService.createUser(user);

        // 将保存后的实体转换为 DTO 返回，保证不暴露敏感信息（如密码）
        return new UserDTO(
                created.getId(),
                created.getUsername(),
                created.getEmail(),
                created.getRole(),
                null  // 确保不把密码泄漏出去
        );
    }

    /**
     * 获取所有用户
     * @return 用户 DTO 列表
     */
    @GetMapping
    public List<UserDTO> getAllUsers() {
        return userService.getAllUsers().stream()
                .map(user -> new UserDTO(user.getId(), user.getUsername(), user.getEmail(), user.getRole()))
                .collect(Collectors.toList());
    }

    /**
     * 获取指定用户
     * 若用户不存在，则在抛出 ResourceNotFoundException
     * @param id 用户ID
     * @return 用户 DTO 对象
     */
    @GetMapping("/{id}")
    public UserDTO getUserById(@PathVariable("id") Long id) {
        User user = userService.getUserById(id);
        return new UserDTO(user.getId(), user.getUsername(), user.getEmail(), user.getRole());
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
