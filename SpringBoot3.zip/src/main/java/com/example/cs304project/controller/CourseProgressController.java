package com.example.cs304project.controller;

public class CourseProgressController {

    //post    /api/process/create     创建学习进度

    //put       /api/process/{processId}/update       更新学习进度

    //get       /api/process/{processId}       根据id获取学习进度

    //get       /api/process/{userId}      获取某学生的学习进度

    //get       /api/process/{userId}/{courseId}/{lectureId}/{slideId}       获取某学生在某课程某讲座的某个课件学习进度

    //delete        /api/process/{processId}/delete       删除学习进度


}
