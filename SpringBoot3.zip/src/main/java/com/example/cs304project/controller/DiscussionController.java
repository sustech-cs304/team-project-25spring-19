package com.example.cs304project.controller;

import com.example.cs304project.dto.DiscussionDTO;
import com.example.cs304project.dto.ResourceDTO;
import com.example.cs304project.service.DiscussionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/discussions")
public class DiscussionController {

    @Autowired
    private DiscussionService discussionService;

    //post /api/discussions/create 发布帖子或回复
    @PostMapping("/create")
    public void createDiscussion(@RequestBody DiscussionDTO discussionDTO){

    }

    //get /api/discussions/{discussionId}/getById 获取帖子详情信息
    @GetMapping("/{discussionId}/getById")
    public ResponseEntity<DiscussionDTO> getDiscussionById(@PathVariable Long discussionId,
                                                           @RequestBody DiscussionDTO discussionDTO){

    }

    //get /api/discussions/{discussionId}/getDiscussionByCourse 获取某课程的全部讨论内容
    @GetMapping("/{courseId}/getDiscussionByCourse")
    public ResponseEntity<List<DiscussionDTO>> getDiscussionByCourse(@PathVariable Long courseId){

    }

    //get /api/discussions/{lectureId}/getDiscussionByLecture 获取某讲座全部回复
    @GetMapping("/{lectureId}/getDiscussionByLecture")
    public ResponseEntity<List<DiscussionDTO>> getDiscussionByLecture(@PathVariable Long lectureId){

    }

    //get /api/discussions/{userId}/getDiscussionByUser 获取某用户全部回复
    @GetMapping("/{userId}/getDiscussionByUser")
    public ResponseEntity<List<DiscussionDTO>> getDiscussionByUser(@PathVariable Long userId){

    }

    //delete /api/discussions/{discussionId}/delete 删除回复
    @DeleteMapping("/{discussionId}/delete")
    public ResponseEntity<String> deleteDiscussion(@PathVariable Long discussionId){
        discussionService.deleteDiscussion(discussionId);
        return ResponseEntity.ok("指定的留言已删除");
    }


}
