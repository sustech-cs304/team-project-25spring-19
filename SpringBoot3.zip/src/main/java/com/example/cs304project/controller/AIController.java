package com.example.cs304project.controller;

public class AIController {

    //post  /api/ai/create    创建ai总结
    public void createAiFeedback(){}

    //put   /api/ai/{aiId}/update    更改ai总结
    public void updateAiFeedback(){}

    //get   /api/ai/{aiId}    根据id获取ai总结
    public void getAiFeedbackById(){}

    //get   /api/ai/{slideId}    获取某个课件的ai总结
    public void getAiFeedbackBySlide(){}

    //get   /api/ai/{submissionId}    获取某个提交的ai总结
    public void getAiFeedbackBySubmission(){}

    //delete   /api/ai/{aiId}/delete     删除ai总结
    public void deleteAiFeedback(){}
}
