package com.example.cs304project.controller;

import com.example.cs304project.dto.CodeResultDTO;
import com.example.cs304project.dto.SubmissionDTO;
import com.example.cs304project.entity.Submission;
import com.example.cs304project.service.SubmissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/submissions")
public class SubmissionController {

    @Autowired
    private SubmissionService submissionService;

    //post /api/submissions/create  创建提交
    @PostMapping("/create")
    public ResponseEntity<SubmissionDTO> createSubmission(SubmissionDTO submissionDTO){
        Submission created = new Submission();
        created.setSummary("");
        created.setContent(submissionDTO.getContent());
        created.setLanguage(submissionDTO.getLanguage());
        created.setResult(submissionService.runSubmission(submissionDTO.getContent(),submissionDTO.getLanguage()));
        created.setScore(submissionDTO.getScore());
        Submission submission = submissionService.createSubmission(submissionDTO.getStudentId(),
                submissionDTO.getExerciseId(),created);
        SubmissionDTO dto = new SubmissionDTO();
        dto.setSubmissionId(submission.getSubmissionId());
        dto.setStudentId(submission.getStudent().getUserId());
        dto.setExerciseId(submission.getExercise().getExerciseId());
        dto.setContent(submission.getContent());
        dto.setLanguage(submission.getLanguage());
        dto.setScore(submission.getScore());
        dto.setSummary(submission.getSummary());
        return ResponseEntity.ok(dto);
    }

    //put /api/submissions/{submissionId}/update 修改提交
    @PutMapping("/{submissionId}/update")
    public ResponseEntity<SubmissionDTO> updateSubmission(@PathVariable Long submissionId,
                                                          @RequestBody SubmissionDTO submissionDTO){
        Submission updated = new Submission();
        updated.setSubmissionId(submissionId);
        updated.setSummary("");
        updated.setContent(submissionDTO.getContent());
        updated.setLanguage(submissionDTO.getLanguage());
        updated.setResult(submissionService.runSubmission(submissionDTO.getContent(),submissionDTO.getLanguage()));
        updated.setScore(submissionDTO.getScore());
        Submission submission = submissionService.updateSubmission(submissionDTO.getStudentId(),
                submissionDTO.getExerciseId(),updated);
        SubmissionDTO dto = new SubmissionDTO();
        dto.setSubmissionId(submission.getSubmissionId());
        dto.setStudentId(submission.getStudent().getUserId());
        dto.setExerciseId(submission.getExercise().getExerciseId());
        dto.setContent(submission.getContent());
        dto.setLanguage(submission.getLanguage());
        dto.setScore(submission.getScore());
        dto.setSummary(submission.getSummary());
        return ResponseEntity.ok(dto);


    }

    //post /api/submissions/runSubmission 实时返回运行的提交结果
    @PostMapping("/runSubmission")
    public ResponseEntity<CodeResultDTO> runSubmission(CodeResultDTO resultDTO){
        CodeResultDTO dto = new CodeResultDTO();
        dto.setCode(resultDTO.getCode());
        dto.setLanguage(resultDTO.getLanguage());
        dto.setResult(submissionService.runSubmission(dto.getCode(),dto.getLanguage()));
        return ResponseEntity.ok(dto);
    }

    //get /api/submissions/{submissionId}/getById 根据id获取提交
    @GetMapping("/{submissionId}/getById")
    public ResponseEntity<SubmissionDTO> getById(@PathVariable Long submissionId){
        Submission submission = submissionService.getSubmissionById(submissionId);
        SubmissionDTO dto = new SubmissionDTO();
        dto.setSubmissionId(submission.getSubmissionId());
        dto.setStudentId(submission.getStudent().getUserId());
        dto.setExerciseId(submission.getExercise().getExerciseId());
        dto.setContent(submission.getContent());
        dto.setLanguage(submission.getLanguage());
        dto.setScore(submission.getScore());
        dto.setSummary(submission.getSummary());
        return ResponseEntity.ok(dto);
    }

    //get /api/submissions/{exerciseId}/getByExercise 获取某练习的所有提交
    @GetMapping("/{exerciseId}/getByExercise")
    public ResponseEntity<List<SubmissionDTO>> getByExercise(@PathVariable Long exerciseId){
        List<Submission> submissions = submissionService.getSubmissionByExercise(exerciseId);
        List<SubmissionDTO> dtos = submissions.stream().map(submission -> {
            SubmissionDTO dto = new SubmissionDTO();
            dto.setSubmissionId(submission.getSubmissionId());
            dto.setStudentId(submission.getStudent().getUserId());
            dto.setExerciseId(submission.getExercise().getExerciseId());
            dto.setContent(submission.getContent());
            dto.setLanguage(submission.getLanguage());
            dto.setScore(submission.getScore());
            dto.setSummary(submission.getSummary());
            return dto;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    //get /api/submissions/{userId}/getByUser 获取某学生的所有提交
    @GetMapping("/{userId}/getByUser")
    public ResponseEntity<List<SubmissionDTO>> getByUser(@PathVariable Long userId){
        List<Submission> submissions = submissionService.getSubmissionByUser(userId);
        List<SubmissionDTO> dtos = submissions.stream().map(submission -> {
            SubmissionDTO dto = new SubmissionDTO();
            dto.setSubmissionId(submission.getSubmissionId());
            dto.setStudentId(submission.getStudent().getUserId());
            dto.setExerciseId(submission.getExercise().getExerciseId());
            dto.setContent(submission.getContent());
            dto.setLanguage(submission.getLanguage());
            dto.setScore(submission.getScore());
            dto.setSummary(submission.getSummary());
            return dto;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    //get /api/submissions/{userId}/{exerciseId}/getByUserExercise 获取某学生某个题的提交
    @GetMapping("/{userId}/{exerciseId}/getByUserExercise")
    public ResponseEntity<List<SubmissionDTO>> getByUserExercise(@PathVariable Long userId,
                                                                 @PathVariable Long exerciseId ){
        List<Submission> submissions = submissionService.getSubmissionByUserExercise(userId,exerciseId);
        List<SubmissionDTO> dtos = submissions.stream().map(submission -> {
            SubmissionDTO dto = new SubmissionDTO();
            dto.setSubmissionId(submission.getSubmissionId());
            dto.setStudentId(submission.getStudent().getUserId());
            dto.setExerciseId(submission.getExercise().getExerciseId());
            dto.setContent(submission.getContent());
            dto.setLanguage(submission.getLanguage());
            dto.setScore(submission.getScore());
            dto.setSummary(submission.getSummary());
            return dto;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    //delete /api/submissions/{submissionId}/delete 删除提交
    @DeleteMapping("/{submissionId}/delete")
    public ResponseEntity<String> delete(@PathVariable Long submissionId){
        submissionService.deleteSubmission(submissionId);
        return ResponseEntity.ok("成功删除提交");
    }


}
