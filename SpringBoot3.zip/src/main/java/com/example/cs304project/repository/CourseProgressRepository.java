package com.example.cs304project.repository;


import com.example.cs304project.entity.CourseProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseProgressRepository extends JpaRepository<CourseProgress,Long> {
}
