package com.example.cs304project.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "AI_Assistant")
public class AI {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long AIId;

    @ManyToOne
    @JoinColumn(name = "slide_id")
    private LectureSlide slide;

    @ManyToOne
    @JoinColumn(name = "submission_id")
    private Submission submission;

    @Column(columnDefinition = "TEXT")
    private String summary;

    @Column(columnDefinition = "TEXT")
    private String mindMap;

    public AI(Long AIId, LectureSlide slide, Submission submission, String summary, String mindMap, String quiz) {
        this.AIId = AIId;

        this.slide = slide;
        this.submission = submission;
        this.summary = summary;
        this.mindMap = mindMap;
        this.quiz = quiz;
    }

    @Column(columnDefinition = "TEXT")
    private String quiz;

    public Long getAIId() {
        return AIId;
    }

    public void setAIId(Long AIId) {
        this.AIId = AIId;
    }


    public LectureSlide getSlide() {
        return slide;
    }

    public void setSlide(LectureSlide slide) {
        this.slide = slide;
    }

    public Submission getSubmission() {
        return submission;
    }

    public void setSubmission(Submission submission) {
        this.submission = submission;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getMindMap() {
        return mindMap;
    }

    public void setMindMap(String mindMap) {
        this.mindMap = mindMap;
    }

    public String getQuiz() {
        return quiz;
    }

    public void setQuiz(String quiz) {
        this.quiz = quiz;
    }

    public AI() {

    }
}
