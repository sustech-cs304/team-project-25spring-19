package com.example.cs304project.dto;

import lombok.*;

public class AIDTO {

    private Long AIId;


    private Long slideId;

    private Long submissionId;

    private String summary;

    private String mindMap;

    private String quiz;

    public Long getAIId() {
        return AIId;
    }

    public void setAIId(Long AIId) {
        this.AIId = AIId;
    }


    public Long getSlideId() {
        return slideId;
    }

    public void setSlideId(Long slideId) {
        this.slideId = slideId;
    }

    public Long getSubmissionId() {
        return submissionId;
    }

    public void setSubmissionId(Long submissionId) {
        this.submissionId = submissionId;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getMindMap() {
        return mindMap;
    }

    public void setMindMap(String mindMap) {
        this.mindMap = mindMap;
    }

    public String getQuiz() {
        return quiz;
    }

    public void setQuiz(String quiz) {
        this.quiz = quiz;
    }
}
