package com.example.cs304project.exception;

public class FileProcessException extends RuntimeException{
    public FileProcessException(String message){
        super(message);
    }
}
