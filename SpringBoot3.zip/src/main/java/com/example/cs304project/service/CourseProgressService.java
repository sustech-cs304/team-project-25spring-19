package com.example.cs304project.service;

public class CourseProgressService {

    //创建学习进度
    public void createProcess(){}

    //更新学习进度
    public void updateProcess(){}

    //根据id获取学习进度
    public void getProcessById(){}

    //获取某学生的学习进度
    public void getProcessByUser(){}

    //获取某学生在某课程某讲座的某个课件学习进度
    public void getProcessByUserCourseLecture(){}

    //删除学习进度
    public void deleteProcess(){}
}
