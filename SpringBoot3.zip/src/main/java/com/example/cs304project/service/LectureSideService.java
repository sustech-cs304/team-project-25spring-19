package com.example.cs304project.service;

import com.example.cs304project.entity.Lecture;
import com.example.cs304project.entity.LectureSlide;
import com.example.cs304project.exception.InvalidRequestException;
import com.example.cs304project.exception.ResourceNotFoundException;
import com.example.cs304project.repository.LectureRepository;
import com.example.cs304project.repository.LectureSlideRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class LectureSideService {

    @Autowired
    private LectureSlideRepository lectureSlideRepository;

    @Autowired
    private LectureRepository lectureRepository;
    //创建新课件
    /*
    * ChatGPT o3
    * 指令：如何实现lectureslidecervice中存储课件的功能
    * 方式：仿写
    * */
    public LectureSlide createSlide(MultipartFile file,Long lectureId,LectureSlide slide) throws IOException {
        LectureSlide lectureSlide = new LectureSlide();
        Lecture lecture = lectureRepository.findById(lectureId)
                .orElseThrow(() -> new ResourceNotFoundException("找不到指定讲座"));
        lectureSlide.setLecture(lecture);
        lectureSlide.setContent(slide.getContent());
        lectureSlide.setUrl(slide.getUrl());
        if (file != null && !file.isEmpty()){
            lectureSlide.setExtractedText(file.getBytes());
        }

        return lectureSlideRepository.save(lectureSlide);

    }
    //更改课件内容或顺序
    public LectureSlide updateSlide(Long lectureId, LectureSlide newSlide){
        Lecture lecture = lectureRepository.findById(lectureId).orElseThrow(() -> new ResourceNotFoundException("找不到指定讲座"));
        LectureSlide oldSlide = lectureSlideRepository.findById(newSlide.getSlideId())
                .orElseThrow(() -> new InvalidRequestException("要更新的课件不存在"));
        oldSlide.setContent(newSlide.getContent());
        oldSlide.setUrl(newSlide.getUrl());
        oldSlide.setExtractedText(newSlide.getExtractedText());
        oldSlide.setSlideId(newSlide.getSlideId());
        oldSlide.setLecture(lecture);
        return oldSlide;

    }

    //根据id获取课件内容
    public LectureSlide getSlideById(Long slideId){
        return lectureSlideRepository.findById(slideId)
                .orElseThrow(() -> new ResourceNotFoundException("找不到指定课件"));
    }


    //获取讲座的所有课件
    public List<LectureSlide> getAllSlides(Long lectureId){
        Lecture lecture = lectureRepository.findById(lectureId).orElseThrow(() -> new ResourceNotFoundException("找不到指定讲座"));
        List<LectureSlide> slides= lectureSlideRepository.findByLecture(lecture);
        if (slides == null || slides.isEmpty()){
            throw new ResourceNotFoundException("指定讲座没有课件");
        }

        return slides;
    }

    //删除课件
    public void deleteSlide(Long lectureSlideId){
        LectureSlide slide = lectureSlideRepository.findById(lectureSlideId)
                .orElseThrow(() -> new ResourceNotFoundException("要删除的课件不存在"));

        lectureSlideRepository.delete(slide);
    }
}
