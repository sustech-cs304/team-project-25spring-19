package com.example.cs304project.service;

public class AIService {

    //创建ai总结
    public void createAiFeedback(){}

    //更改ai总结
    public void updateAiFeedback(){}

    //根据id获取ai总结
    public void getAiFeedbackById(){}

    //获取某个课件的ai总结
    public void getAiFeedbackBySlide(){}

    //获取某个提交的ai总结
    public void getAiFeedbackBySubmission(){}

    //删除ai总结
    public void deleteAiFeedback(){}
}
