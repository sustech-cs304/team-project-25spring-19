package com.example.cs304project.service;

public class AiTool {

    public void AiSummary(){}

    public void AiMindMap(){}

    public void AiJudge(){}
}
