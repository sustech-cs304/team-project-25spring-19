package com.example.cs304project.exception;

public class AIProcessingException extends RuntimeException{
    public AIProcessingException(String message){
        super(message);
    }
}
