package com.example.cs304project.exception;

public class CodeExecutionException extends RuntimeException{
    public CodeExecutionException(String message){
        super(message);
    }
}
