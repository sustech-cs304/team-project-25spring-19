package com.example.cs304project.config;

public class test {
    public static void main(String[] args) {
        System.out.println(Math.max(1,9));
    }
}
